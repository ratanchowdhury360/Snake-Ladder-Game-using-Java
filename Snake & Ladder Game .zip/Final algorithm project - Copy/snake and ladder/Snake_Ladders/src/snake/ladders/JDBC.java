package snake.ladders;

import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//create database snakes_and_ladders;
//create table accounts(
//    id int primary key AUTO_INCREMENT,
//    name varchar(100) not null UNIQUE,
//    phone varchar(15) not null unique,
//    pass varchar(100) not null,
//    totalPoints int default 0
//)
public class JDBC {
    static  String dbURL = "jdbc:mysql://localhost:3306/snakes_and_ladders";
    static  String user = "root";
    static  String pass = "";
          
    public static Connection getConnection(){
        Connection connect = null;
        try{
//            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection(dbURL,user,pass);
        }
        catch(SQLException e){
            System.out.println("Error while connecting database.."+e.getMessage());
        }
        return connect;
    }
    
    
    static void updateTotalPoints(player[] obj,int player){
            try{
                Connection con;
                con = JDBC.getConnection();
                try (Statement st = con.createStatement()) {
                    String queryToInsert = "update accounts set totalpoints = "+obj[player].totalPoints+" where name = '"+obj[player].playerName+"'";
                    st.execute(queryToInsert);
                    
                    con.close();
                }
            }
            catch(SQLException e){
                System.out.println("Error while connecting database.."+e.getMessage());
            }
    }
    static void updatePlaying(player[] obj,int player){
            try{
                Connection con;
                con = JDBC.getConnection();
                try (Statement st = con.createStatement()) {
                    String queryToInsert = "update accounts set playing = 'false' where name = '"+obj[player].playerName+"'";
                    st.execute(queryToInsert);
                    
                    con.close();
                }
            }
            catch(SQLException e){
                System.out.println("Error while connecting database.."+e.getMessage());
            }
    }
}
