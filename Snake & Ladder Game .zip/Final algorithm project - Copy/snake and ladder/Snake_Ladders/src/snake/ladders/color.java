package snake.ladders;

public class color {
    final static String RESET = "\u001B[0m";
    final static String RED = "\u001B[31m";
    final static String GREEN = "\u001B[32m";
    final static String YELLOW = "\u001B[33m";  
    static final String BLACK = "\u001B[30m";
    static final String LIGHT_YELLOW = "\u001B[93m";
    static final String YELLOW_BACKGROUND = "\u001B[43m";
    static final String BLUE = "\u001B[34m";
    static final String PURPLE = "\u001B[35m";
    static final String CYAN = "\u001B[36m";
    static final String WHITE = "\u001B[37m";
    static final String BOLD = "\u001B[1m";
    static final String UNBOLD = "\u001B[21m";
    static final String UNDERLINE = "\u001B[4m";
    static final String STOP_UNDERLINE = "\u001B[24m";
    static final String BLINK = "\u001B[5m";  
    static final String Magenta = "\u001b[35m";
}
